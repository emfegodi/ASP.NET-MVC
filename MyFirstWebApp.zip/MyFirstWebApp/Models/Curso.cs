﻿namespace MyFirstWebApp.Controllers
{
    public class Curso
    {
        public int IDCURSO { get; set; }
        public string NOMBRE { get; set; }
        public string DESCRIPCION { get; set; }
        public int BHABILITADO { get; set; }
    }
}
