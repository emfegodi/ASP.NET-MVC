﻿using System.Linq;
using System.Web.Mvc;

namespace MyFirstWebApp.Controllers
{
    public class CursoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public string message()
        {
            return "Bienvenido al curso ASP.NET MVC";
        }

        public string gretting(string name)
        {
            return "Hi, how are u? " + name;
        }
        public string completeGretting(string name, string lastname)
        {
            return "Hi " + name + " " + lastname;
        }

        public JsonResult listarCurso()
        {
            PruebaDataContext bd = new PruebaDataContext("Server=localhost;Database=SistemaMatricula;Trusted_Connection=True;");
            var lista = bd.Cursos.Where( p => p.BHABILITADO.Equals(1)).Select(p => new {p.IIDCURSO, p.NOMBRE, p.DESCRIPCION} ).ToList();

            return Json( lista, JsonRequestBehavior.AllowGet );
        }
    }
}
