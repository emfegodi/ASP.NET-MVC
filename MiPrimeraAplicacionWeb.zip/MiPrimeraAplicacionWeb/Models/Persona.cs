﻿namespace MiPrimeraAplicacionWeb.Models
{
    public class Persona
    {
        public int idPersona { get; set; }  
        public string nombre { get; set; }
        public string apellidoPaterno { get; set; }
    }
}
