using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MiPrimeraAplicacionWeb.Views.Periodo
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
