﻿using Microsoft.AspNetCore.Mvc;

namespace MiPrimeraAplicacionWeb.Controllers
{
    public class CursoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public string message()
        {
            return "Bienvenido al curso ASP.NET MVC";
        }

        public string gretting(string name)
        {
            return "Hi, how are u? " + name;
        }
        public string completeGretting(string name, string lastname)
        {
            return "Hi " + name + " " + lastname;
        }
    }
}
