﻿using Microsoft.AspNetCore.Mvc;
using MiPrimeraAplicacionWeb.Models;
using System.Diagnostics;

namespace MiPrimeraAplicacionWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Tabla()
        {
            return View();
        }
        public IActionResult ComboBox()
        {
            return View();
        }

        public IActionResult TablaJS()
        {
            return View();
        }

        public JsonResult listarPersonas()
        {
            List<Persona> listaPersonas = new List<Persona>
            {
                new Persona{idPersona=1, nombre="Pedro", apellidoPaterno="Perez"},
                new Persona{idPersona=2, nombre="Marco", apellidoPaterno="Perez"},
                new Persona{idPersona=3, nombre="Maria", apellidoPaterno="Perez"}
            };
            return Json(listaPersonas);
        }
    }
}