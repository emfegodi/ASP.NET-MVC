﻿using Microsoft.AspNetCore.Mvc;

namespace MiPrimeraAplicacionWeb.Controllers
{
    public class PeriodoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
