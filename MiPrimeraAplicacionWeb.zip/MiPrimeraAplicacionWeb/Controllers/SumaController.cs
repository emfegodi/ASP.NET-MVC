﻿using Microsoft.AspNetCore.Mvc;

namespace MiPrimeraAplicacionWeb.Controllers
{
    public class SumaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
