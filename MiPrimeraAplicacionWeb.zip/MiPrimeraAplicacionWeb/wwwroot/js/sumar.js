﻿
$("#btnSumar").click(function () {
    const resultadoSuma = ($("#numUno").val() * 1) + ($("#numDos").val() * 1);
    $("#lblResultadoSuma").text("El resultado de la sumas es: " + resultadoSuma);
})

$("#btnLimpiar").click(function () {
    $("#numUno").val("");
    $("#numDos").val("");
    $("#lblResultadoSuma").empty();
})